function main(str) {
  // 定义中文符号和英文符号之间的映射关系
  const symbolMap = {
    "×": "*",
    "x": "*",
    "÷": "/",
    "－": "-",
    "−": "-",
    "（": "(",
    "）": ")",
    "＋": "+",
    "[": "(",
    "]": ")",
    "{": "(",
    "}": ")",
    "｛": "(",
    "｝": ")",
    "^": "**",
  };
  const regex1 = /=\-?( +)?[0-9]+(\.[0-9]+)?( +)?$/;
  const regex2 = /=( +)?$/;
  // 按换行分割字符串为数组
  const lines = str.split(/\n/);
  // 获取最后一行内容
  const newLines = lines.map((line) => {
    if (regex1.test(line)) {
      return line;
    }
    const devideLine = line.replace(/^ +|( +)?=( +)?| +$/g, "").split(/ {1,}|:|：|；|;|，|年|月|日|天|周/);
    var formula = devideLine[devideLine.length - 1];
    // 遍历映射关系，替换中文符号为英文符号
    for (const [chineseSymbol, englishSymbol] of Object.entries(symbolMap)) {
      formula = formula.replaceAll(chineseSymbol, englishSymbol);
    }
    try {
      const result = eval(formula);
      if (isNaN(result)) {
        return line;
      } else {
        if (regex2.test(line)) {;
          return line + Math.round(result*100000000000)/100000000000;
        } else {
          return line + "=" + Math.round(result*100000000000)/100000000000;

        }
      }
    } catch (err) {
      return line;
    }
  });
  return newLines.join("\n");
}